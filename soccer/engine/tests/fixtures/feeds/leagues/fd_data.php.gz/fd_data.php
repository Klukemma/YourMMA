<HTML>
<HEAD>
<TITLE>Football Results, Statistics & Soccer Betting Odds Data</TITLE>
<META NAME="description" CONTENT="Football results, fixed odds, total goals and Asian Handicap betting odds data in CSV and Excel spreadsheet format to help punters develop soccer betting systems to beat the bookmaker and make a profit">
<META NAME="keywords" CONTENT="soccer results, soccer betting, football results, fixed odds betting, football betting, gambling, football data, soccer data, fixed odds gambling, Asian handicap, bookmaker, bookie, match statistics, goals, half time, full time, corners, shots, overround, ratings, Rateform, forecasting, prediction, strategy, gambling system">
<META NAME="revisit-after" CONTENT="7">
<META HTTP-EQUIV="author" CONTENT="Joesph Buchdahl">
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=ISO-8859-1">
<link rel="stylesheet" href="style.css">
</HEAD>

<body BGCOLOR="#FFFFFF" TEXT="#000000" ALINK="#6666CC" VLINK="#6666CC" LINK="#6666CC">

<!-- Place this render call where appropriate -->
<script type="text/javascript">
  window.___gcfg = {lang: 'en-GB'};

  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/plusone.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
</script>

<TABLE align=center CELLSPACING=0 BORDER=0 CELLPADDING=0 WIDTH=800>
<TR><td align=left><A HREF="https://football-data.co.uk/"><IMG SRC="https://football-data.co.uk/logo2.jpg" BORDER="0" ALT="Football Betting - Football Results - Free Bets"></A></td>

<td colspan=5 align=right>

<a href="https://valuebetfactory.com/?utm_source=football-data&utm_medium=display&utm_campaign=odds-drop-2026-10&utm_content=black-red-468x60" target="_blank"><img src="https://football-data.co.uk/banners/vbf_redblack_468x60.gif" border="0" width="468" height="60" alt="ValueBetFactory"></a>


<!-- 

<a target="_blank" href="https://www.pinnacleoddsdropper.com/?via=joseph&ref=Buchdahl"> <img width=468 src="https://football-data.co.uk/banners/468x60-Dropping Odds.png"></a>

<A target="_blank" HREF="https://strategies.bet2invest.com/r/joseph"><img width=468 src="https://football-data.co.uk/banners/AD_HISTORICAL_ODDS.gif"></a><P>

 -->


</TD></TR>
<tr><td height=19 valign=top>
<select onChange="location=this.options[this.selectedIndex].value;" style="font-family:'Verdana';color:#000000;background-color:#FFFFFF;font-size:7pt;">
<option>Network Sites
<option>
<option value="https://football-data.co.uk">Football Betting</option>
<option value="https://livescore.football-data.co.uk">Football Livescore</option>
<option value="https://betting.football-data.co.uk">Learn to Bet</option>
<option value="http://tennis-data.co.uk">Tennis Betting</option>
<option value="http://livescore.tennis-data.co.uk">Tennis Livescore</option>
</select>
</td>
<td align=right width=290 align="right">
Updated: 	 29/10/26&nbsp;
<A HREF="https://football-data.co.uk/disclaimer.php"><img width=19 height=19 border=0 valign="middle" src="https://football-data.co.uk/banner/18.gif" alt="legal disclaimer"></a>&nbsp;<a href="https://www.gambleaware.org/" target="_blank" title="GambleAware"><img valign="middle" height=12 border=0 valign="middle" src="https://football-data.co.uk/banner/gambleaware.jpg" alt="GambleAware"></a>&nbsp;<A target="blank" HREF="https://twitter.com/12Xpert" title="Follow me on X"><img height=19 border=0 valign="middle" src="https://football-data.co.uk/banner/twitter.jpg" alt="Twitter"></a>&nbsp;<A target="blank"  HREF="https://bsky.app/profile/12xpert.bsky.social" title="Follow me on Blue Sky"><img height=19 border=0 valign="middle" src="https://football-data.co.uk/banner/bluesky.jpg" alt="BlueSky"></a>

</TD>
</TR>
</table>

<TABLE align=center CELLSPACING=1 BORDER=0 CELLPADDING=0 WIDTH=800>
<tr><td height=4></td></tr>
</table>

<TABLE align=center CELLSPACING=1 BORDER=0 CELLPADDING=1 WIDTH=800 bgcolor="#999999">
<tr>
<td align=center bgcolor="#F3F3F3"><div class="header"><B><A HREF="https://football-data.co.uk">Home</A></B></div></td>
<td align=center bgcolor="#F3F3F3"><div class="header"><B><A target="_blank" HREF="https://campaigns.williamhill.com/C.ashx?btag=a_87b_815c_&affid=1213609&siteid=87&adid=815&c=">Free Bets</A></B></div></td>
<td align=center bgcolor="#F3F3F3"><div class="header"><B><A HREF="https://livescore.football-data.co.uk">Livescores</A></B></div></td>
<td align=center bgcolor="#F3F3F3"><div class="header"><B><A HREF="https://football-data.co.uk/thestatsapi.php">Football API</A></B></div></td>
<td align=center bgcolor="#F3F3F3"><div style="margin-top:1px; margin-left:1px; margin-right:1px; margin-bottom:1px;"><B><A HREF="https://football-data.co.uk/books.php">Betting Books</A></B></div></td>
<td align=center bgcolor="#F3F3F3"><div style="margin-top:1px; margin-left:1px; margin-right:1px; margin-bottom:1px;"><B><A HREF="https://betting.football-data.co.uk/">Learn</A></B></div></td>
<td align=center bgcolor="#F3F3F3"><div class="header"><B><A HREF="http://tennis-data.co.uk" TARGET="_blank">Tennis Data</A></B></div></td>
<td align=center bgcolor="#F3F3F3"><div class="header"><B><A HREF="https://www.gambleaware.org/" TARGET="_blank">Safer Gambling</A></B></div></td>
<td align=center bgcolor="#F3F3F3"><div class="header"><B><A HREF="https://football-data.co.uk/contact.php">Contact</A></B></div></td>

</tr>
</table>

<TABLE align=center CELLSPACING=1 BORDER=0 CELLPADDING=0 WIDTH=800>
<tr><td height=5></td></tr>


<tr><td height=5></td></tr>
</table>







<TABLE align=center CELLSPACING=0 BORDER=0 CELLPADDING=0 WIDTH=800>
<tr><td height=5></td></tr>

<TR>
<TD width=160 align=left valign=top>

<!-- <a target="_blank" href="https://campaigns.williamhill.com/C.ashx?btag=a_87b_1456c_&affid=1213609&siteid=87&adid=1456&c="><img width=160 src="https://football-data.co.uk/banners/WillHill30.jpg"></a><P>-->

<A target="_blank" HREF="https://valuebetfactory.com/?utm_source=football-data&utm_medium=display&utm_campaign=odds-drop-2026-10&utm_content=black-red-160x160"><img width=160 src="https://football-data.co.uk/banners/vbf_redblack_160x160.gif"></a><P>

<table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#999999">
<tr><td bgcolor="#AAAAAA"><div class="menus"><B><FONT COLOR="#FFFFFF">ODDS DROP SYSTEMS</FONT></B></div></td></tr>
<tr><td class="menustd"><div class="menus"><B><A HREF="https://football-data.co.uk/pinnacle_odds_dropper.php">Pinnacle Odds Drop Alerts <font color="red">HOT</font></A></B></div></td></tr>
<tr><td class="menustd"><div class="menus"><B><A target="_blank" HREF="https://valuebetfactory.com/?utm_source=football-data&utm_medium=display&utm_campaign=odds-drop-2026-10&utm_content=black-red-160x160">Value Bet Alerts <font color="red">NEW</font></A></B></div></td></tr>
<tr><td class="menustd"><div class="menus"><B><A HREF="https://football-data.co.uk/opening_odds_alerts.php">Opening Odds Alerts</A></B></div></td></tr>
<tr><td class="menustd"><div class="menus"><B><A HREF="https://football-data.co.uk/pinnacle_odds_dropper_bet_tracker.php">CLV Bet Tracker</A></B></div></td></tr>
</table><BR>

<!-- 
<A target="_blank" HREF="https://www.pinnacleoddsdropper.com/?via=joseph&ref=Buchdahl"><img width=160 src="https://football-data.co.uk/banners/125x125-Dropping Odds.png" width=160></a><P>-->


<A target="_blank" HREF="https://football-data.co.uk/opening_odds_alerts.php"><img src="https://football-data.co.uk/banners/125x125-Opening Odds.png" width=160></a><P>



<table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#999999">
<tr><td bgcolor="#AAAAAA"><div class="menus"><B><FONT COLOR="#FFFFFF">BETTING ARTICLES</FONT></B></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/blog/pinnacle_limit.php"><B>Pinnacle's Betting Limits</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/blog/backtesting_in_sports_betting.php"><B>Bet2Invest Strategy Builder</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/blog/tipstrr.php"><B>tipstrr</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/blog/betshare.php"><B>Betshares in Overs/Unders</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/blog/closing_odds.php"><B>Analysing Tipsters</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/blog/asian_handicap.php"><B>Asian Handicap</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/blog/pinnacle_efficiency.php"><B>Closing Odds</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/blog/premiership_unpredictable.php"><B>Unpredictable Premiership</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/blog/psychology_of_betting.php"><B>Betting Psychology</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/blog/steamers_and_drifters.php"><B>Steamers & Drifters</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/blog/beat_the_market.php"><B>How Good are Tipsters?</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/blog/hot_hand_streaks.php"><B>Betting Hot Hands</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/blog/favourite_longshot_bias_revisited.php"><B>Favourite-Longshot Bias</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/blog/favourite_longshot_bias_revisited_again.php"><B>Favourite-Longshot Bias 2</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/blog/unwise_points_spread.php"><B>Point Spread Bias</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/blog/power_ratings.php"><B>Power Ratings</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/blog/wisdom_of_the_crowd.php"><B>Wisdom of Crowds</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/blog/wisdom_of_crowd_betting_system_closing_odds.php"><B>Wisdom of Crowds 2</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/blog/sports_betting_random.php"><B>Is Betting Random?</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/blog/monkeys_throwing_darts.php"><B>Monkeys Throwing Darts</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/blog/sports-betting_winners_and_losers.php"><B>How Many Win?</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/blog/profitable_betting_system.php"><B>Hot Hand Fallacy</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/blog/luck_skill_sports_betting.php"><B>Luck & Skill</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/blog/kelly_staking.php"><B>Kelly Staking</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/blog/martingale_progressive_staking.php"><B>Progressive Staking</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/blog/tipster-verification.php"><B>Tipster Verification</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/blog/Wald_Wolfowitz.php"><B>Scam Tipsters</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/blog/fake_tipster_betting_history.php"><B>Scam Tipsters 2</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/blog/model_testing.php"><B>Betting Model Testing</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/blog/archive.php"><B>Other Articles</B></A></div></td></tr>
</table><BR>



<!--
<A target="_blank" HREF="https://bet2invest.com/en/offers?affiliate=12Xpert#opening-odds"><img src="https://football-data.co.uk/banners/banner-3.png"></a><P>
-->

<!--
<a target="_blank" href="https://campaigns.williamhill.com/C.ashx?btag=a_87b_1052c_&affid=1213609&siteid=87&adid=1052&c="> <img width=100% src="https://s0.2mdn.net/simgad/6555778137942114752"></a>-->

<A target="_blank" HREF="https://www.pinnacleoddsdropper.com/?via=joseph&ref=Buchdahl"><img width=160 src="https://football-data.co.uk/banners/125x125-Bet Tracker.png" width=160></a><P>


</TD>

<td width=10></td>

<TD valign=top>

<P align=center><font size="2"><b>Historical Football Results and Betting Odds Data</b></font><BR>
<b>32 seasons results | 27 seasons betting odds | 27 seasons match stats<BR>
All FREE!!!  Access Data via Country Links</b>
</P>

<P align=justify>Football-Data provides the football bettor with historical computer-ready (Excel/CSV) football results, match statistics and betting odds data for use with spreadsheet applications, to help with the development and analysis of football betting systems. What's more, it's all <b>FREE</b>, however its use is intended for private individuals only, <b>NOT</b> commerical or data training products using automated bots/scrapers/AI.

<hr>
<P align=justify>My data is free, but for those who want a subscription API service, I am now partnering with <a target="_blank" href="https://thestatsapi.com?via=joseph"><b>TheStatsAPI</b></a>. See my <a href="thestatsapi.php"><b>review of their service</b></a> for more details. 
<hr>

<P align=justify>Football-Data's spreadsheet data takes the time out of recompiling pages and pages of results data and past betting odds found on a number of football results and odds comparison</a> websites.</p>

<P align=justify>Download Football-Data's FREE PDF guide to <a href="ratings.pdf">Rating Systems for Match Prediction</a>, and discover how ratings analysis using computer-ready results and betting oddds data can help one to establish a betting edge.</P>

<P align=justify>Follow when new data are added.

<P align=justify><a href="https://twitter.com/12Xpert" class="twitter-follow-button" data-show-count="false" data-show-screen-name="false">Follow @12Xpert</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>

<P align=justify>Access fulltime and halftime results for up to 22 European league divisions from 25 seasons back to 1993/94. Additional match statistics since 2000/01, including shots on goal, corners, fouls, offsides, bookings, red cards and referees, are also available for the major European football leagues, including the English Premiership and lower divisions, the Socttish Premiersip, German Budnesliga, Spanish la Liga, Italian Serie A and French Championnat.

<P align=justify>Historical match betting odds data from up to 10 major online bookmakers are available back to 2000/01. Since 2005/06 average and maximum prices for match betting, total goals and Asian handicap have also been collected from Betbrain (from Oddsportal since 2019/20). Since 2017/2018, match statistics are available for all 22 divisions. Since 2019/20 I have collected two sets of odds. The first set is collected after market opening at times specified on my <a href="matches.php">fixtures</a> page. The second set are the closing odds ('C' included the data column headings). Closing home-draw-away odds are also available for Pinnacle bookmaker only back to 2012/13). In earlier seasons, there are only the pre-closing odds.

<P align=justify>** Since 23/07/2025 Pinnacle's public API for odds delivery has become unreliable meaning their odds are systematically out of date relative to odds for other bookmakers, including both the pre-closing and closing odds. Consequently they should be used with caution when undertaking any betting analyses, and are no longer being included for the calculation of market average and maximum odds.

<P align=justify>Additionally, Football-data now provides data for 16 other worldwide premier divisions, with fulltime results and closing match odds (best and average market price, and Pinnacle odds) dating back to 2012/13.

<P align=justify>Fixtures and betting odds for upcoming games are also are made available, collected Friday afternoons for weekend fixtures, and on Tuesday afternoons for midweeek games.

<P align=justify>Check out an <A HREF="example.csv">example datasheet</A> and a set of <A HREF="notes.txt"><B>Notes</B></A> that describe the available data. The table below provides quick links to all the data files, with descriptions of exactly what data can be found in each data file. Data files can also be accessed via the <b>country links</b> in the right hand menu.</P>

<a name="download"></a>
<P align=left><b>Main Leagues</b></P>

<table cellspacing=2 border=0>
<tr><td><IMG align=right SRC="http://livescore.football-data.co.uk/flags/england.gif" BORDER="0" ALIGN="Absmiddle">&nbsp;&nbsp;</td><td><A HREF="englandm.php">England Football Results</A>&nbsp;&nbsp;</td><td>Premiership & Divs 1,2,3 & Conference</td></tr>
<tr><td><IMG align=right SRC="http://livescore.football-data.co.uk/flags/scotland.gif" BORDER="0" ALIGN="Absmiddle">&nbsp;&nbsp;</td><td><A HREF="scotlandm.php">Scotland Football Results</A>&nbsp;&nbsp;</td><td>Premiership & Divs 1,2 & 3</td></tr>
<tr><td><IMG align=right SRC="http://livescore.football-data.co.uk/flags/germany.gif" BORDER="0" ALIGN="Absmiddle">&nbsp;&nbsp;</td><td><A HREF="germanym.php">Germany Football Results</A>&nbsp;&nbsp;</td><td>Bundesligas 1 & 2</td></tr>
<tr><td><IMG align=right SRC="http://livescore.football-data.co.uk/flags/Italy.gif" BORDER="0" ALIGN="Absmiddle">&nbsp;&nbsp;</td><td><A HREF="italym.php">Italy Football Results</A>&nbsp;&nbsp;</td><td>Serie A & B</td></tr>
<tr><td><IMG align=right SRC="http://livescore.football-data.co.uk/flags/Spain.gif" BORDER="0" ALIGN="Absmiddle">&nbsp;&nbsp;</td><td><A HREF="spainm.php">Spain Football Results</A>&nbsp;&nbsp;</td><td>La Liga (Premera & Segunda)</td></tr>
<tr><td><IMG align=right SRC="http://livescore.football-data.co.uk/flags/France.gif" BORDER="0" ALIGN="Absmiddle">&nbsp;&nbsp;</td><td><A HREF="francem.php">France Football Results</A>&nbsp;&nbsp;</td><td>Le Championnat & Division 2</td></tr>
<tr><td><IMG align=right SRC="http://livescore.football-data.co.uk/flags/holland.gif" BORDER="0" ALIGN="Absmiddle">&nbsp;&nbsp;</td><td><A HREF="netherlandsm.php">Netherlands Football Results</A>&nbsp;&nbsp;</td><td>KPN Eredivisie</td></tr>
<tr><td><IMG align=right SRC="http://livescore.football-data.co.uk/flags/Belgium.gif" BORDER="0" ALIGN="Absmiddle">&nbsp;&nbsp;</td><td><A HREF="belgiumm.php">Belgium Football Results</A>&nbsp;&nbsp;</td><td>Jupiler League</td></tr>
<tr><td><IMG align=right SRC="http://livescore.football-data.co.uk/flags/Portugal.gif" BORDER="0" ALIGN="Absmiddle">&nbsp;&nbsp;</td><td><A HREF="portugalm.php">Portugal Football Results</A>&nbsp;&nbsp;</td><td>Liga I</td></tr>
<tr><td><IMG align=right SRC="http://livescore.football-data.co.uk/flags/Turkey.gif" BORDER="0" ALIGN="Absmiddle">&nbsp;&nbsp;</td><td><A HREF="turkeym.php">Turkey Football Results</A>&nbsp;&nbsp;</td><td>Ligi 1</td></tr>
<tr><td><IMG align=right SRC="http://livescore.football-data.co.uk/flags/Greece.gif" BORDER="0" ALIGN="Absmiddle">&nbsp;&nbsp;</td><td><A HREF="greecem.php">Greece Football Results</A>&nbsp;&nbsp;</td><td>Ethniki Katigoria</td></tr>
</table>


<P align=left><b>Extra Leagues</b></P>

<table cellspacing=2 border=0>
<tr><td><IMG align=right SRC="http://livescore.football-data.co.uk/flags/Argentina.gif" BORDER="0" ALIGN="Absmiddle">&nbsp;&nbsp;</td><td><A HREF="Argentina.php">Argentina Football Results</A>&nbsp;&nbsp;</td><td>Primera Division</td></tr>
<tr><td><IMG align=right SRC="http://livescore.football-data.co.uk/flags/Austria.gif" BORDER="0" ALIGN="Absmiddle">&nbsp;&nbsp;</td><td><A HREF="Austria.php">Austria Football Results</A>&nbsp;&nbsp;</td><td>Bundesliga</td></tr>
<tr><td><IMG align=right SRC="http://livescore.football-data.co.uk/flags/Brazil.gif" BORDER="0" ALIGN="Absmiddle">&nbsp;&nbsp;</td><td><A HREF="Brazil.php">Brazil Football Results</A>&nbsp;&nbsp;</td><td>Serie A</td></tr>
<tr><td><IMG align=right SRC="http://livescore.football-data.co.uk/flags/China.gif" BORDER="0" ALIGN="Absmiddle">&nbsp;&nbsp;</td><td><A HREF="China.php">China Football Results</A>&nbsp;&nbsp;</td><td>Super League</td></tr>
<tr><td><IMG align=right SRC="http://livescore.football-data.co.uk/flags/Denmark.gif" BORDER="0" ALIGN="Absmiddle">&nbsp;&nbsp;</td><td><A HREF="Denmark.php">Denmark Football Results</A>&nbsp;&nbsp;</td><td>Superliga</td></tr>
<tr><td><IMG align=right SRC="http://livescore.football-data.co.uk/flags/Finland.gif" BORDER="0" ALIGN="Absmiddle">&nbsp;&nbsp;</td><td><A HREF="Finland.php">Finland Football Results</A>&nbsp;&nbsp;</td><td>Veikkausliiga</td></tr>
<tr><td><IMG align=right SRC="http://livescore.football-data.co.uk/flags/Ireland.gif" BORDER="0" ALIGN="Absmiddle">&nbsp;&nbsp;</td><td><A HREF="Ireland.php">Ireland Football Results</A>&nbsp;&nbsp;</td><td>Premier Division</td></tr>
<tr><td><IMG align=right SRC="http://livescore.football-data.co.uk/flags/Japan.gif" BORDER="0" ALIGN="Absmiddle">&nbsp;&nbsp;</td><td><A HREF="Japan.php">Japan Football Results</A>&nbsp;&nbsp;</td><td>J-League</td></tr>
<tr><td><IMG align=right SRC="http://livescore.football-data.co.uk/flags/Mexico.gif" BORDER="0" ALIGN="Absmiddle">&nbsp;&nbsp;</td><td><A HREF="Mexico.php">Mexico Football Results</A>&nbsp;&nbsp;</td><td>Liga MX</td></tr>
<tr><td><IMG align=right SRC="http://livescore.football-data.co.uk/flags/Norway.gif" BORDER="0" ALIGN="Absmiddle">&nbsp;&nbsp;</td><td><A HREF="Norway.php">Norway Football Results</A>&nbsp;&nbsp;</td><td>Eliteserien</td></tr>
<tr><td><IMG align=right SRC="http://livescore.football-data.co.uk/flags/Poland.gif" BORDER="0" ALIGN="Absmiddle">&nbsp;&nbsp;</td><td><A HREF="Poland.php">Poland Football Results</A>&nbsp;&nbsp;</td><td>Ekstraklasa</td></tr>
<tr><td><IMG align=right SRC="http://livescore.football-data.co.uk/flags/Romania.gif" BORDER="0" ALIGN="Absmiddle">&nbsp;&nbsp;</td><td><A HREF="Romania.php">Romania Football Results</A>&nbsp;&nbsp;</td><td>Liga 1</td></tr>
<tr><td><IMG align=right SRC="http://livescore.football-data.co.uk/flags/Russia.gif" BORDER="0" ALIGN="Absmiddle">&nbsp;&nbsp;</td><td><A HREF="Russia.php">Russia Football Results</A>&nbsp;&nbsp;</td><td>Premier League</td></tr>
<tr><td><IMG align=right SRC="http://livescore.football-data.co.uk/flags/Sweden.gif" BORDER="0" ALIGN="Absmiddle">&nbsp;&nbsp;</td><td><A HREF="Sweden.php">Sweden Football Results</A>&nbsp;&nbsp;</td><td>Allsvenskan</td></tr>
<tr><td><IMG align=right SRC="http://livescore.football-data.co.uk/flags/swiss.gif" BORDER="0" ALIGN="Absmiddle">&nbsp;&nbsp;</td><td><A HREF="Switzerland.php">Switzerland Football Results</A>&nbsp;&nbsp;</td><td>Super League</td></tr>
<tr><td><IMG align=right SRC="http://livescore.football-data.co.uk/flags/USA.gif" BORDER="0" ALIGN="Absmiddle">&nbsp;&nbsp;</td><td><A HREF="USA.php">USA Football Results</A>&nbsp;&nbsp;</td><td>MLS</td></tr>
</table>


<P align=justify>Why not also visit the network partner <a href="http://www.tennis-data.co.uk" target="_blank">Tennis-Data</a> for <a href="http://www.tennis-data.co.uk" target="_blank">tennis results and betting odds</a> data. As for Footballl-Data, all data is now FREE!!!</P>

<P align=justify>All files are available in CSV/Excel format for PC Windows operating systems, and are at least updated twice weekly (Sunday nights and Wednesday nights). CSV format is the industry standard comma delimited file format allowing compatibility with many computer spreadsheet applications. Commas are used to separate columns of data. They will only be seen if a CSV file is opened in a text editor. Football-Data's preferred spreadsheet application is Microsoft Excel, offering a full range of analytical functions to test  betting systems developed from match and odds data.

<!-- 
<P align=justify>You might also consider <b><a href="https://timeserieslab.com/downloads_sp.html" target="_blank">Time Series Lab's Sports Statistics Package</a></b> for analysing, modelling, and forecasting of time series focusing on sports results. The software allows you to choose from several probability distributions and model specifications to extract sports team strengths from your data. The software is based on football models that appeared in the academic literature. There is a module that allows you to directly download Football-Data files into the GUI. -->

<P align=justify>Football-Data would like to acknowledge the following sources which are currently utilised in the compilation of Football-Data's results and odds files.<BR><BR>

<B>Results:</B><BR>
<A HREF="http://www.xscores.com" TARGET="_blank">Xscores</A>
<BR>
<A HREF="http://www.sportinglife.com/football/" TARGET="_blank">Sportinglife</A>
<BR>
<A HREF="http://www.bbc.co.uk/sport/football/results" TARGET="_blank">BBC Football </A>
<BR>
<A HREF="http://soccernet.espn.go.com" TARGET="_blank">ESPN Soccer </A> and <a href="flashscore.com" target="_blank">Flashscore</a>.
<BR><BR>

<B>Betting odds:</B><BR>
<A HREF="http://www.betbrain.com" TARGET="_blank">Betbrain</A><BR>
<A HREF="http://www.oddsportal.com" TARGET="_blank">Oddsportal</A></P>

<B>Match Statistics:</B><BR>
<A HREF="http://www.sportinglife.com" TARGET="_blank">Sportinglife</A> (UK match statistics until 2011/12 season)<sup>*</sup><BR>
<A HREF="http://www.bbc.co.uk/sport/football/results" TARGET="_blank">BBC Football</A> (UK match statistics from 2012/13 season)<sup>*</sup><BR>
<A HREF="http://soccernet.espn.go.com" TARGET="_blank">ESPN Soccer</A> (European league match statistics)<BR>
<A HREF="http://www.bundesliga.de" TARGET="_blank">Bundesliga</A><BR>
<A HREF="http://www.gazzetta.it" TARGET="_blank">Gazzetta.it</A><BR>
<A HREF="http://www.football.fr" TARGET="_blank">Football.fr</A><BR>

<sup>*</sup>English Conference match statistics for 2013/14 come from Sportinglife.

</P>

<P align=justify>[Please note Football-Data cannot be responsible for any data inaccuracies, either at scoure of duting seconday compilation. All data provided by Football-Data are made available for the purposes of league match prediction only.]


<P align=justify>If you have any questions about either the data or how it can be used for your own betting system, just contact <A HREF="contact.php">Football-Data</A></P>

<P>
<a href="https://www.gambleaware.org/" target="_blank"><img src="https://football-data.co.uk/banner/gambleaware.jpg"></a>
</TD>

<td width=10></td>

<td valign=top width=152>

<a target="_blank" href="https://thestatsapi.com?via=joseph"><img width=152 src="https://football-data.co.uk/banners/statsapi.jpg"></a><P>

<a target="_blank" href="https://oddsrelay.io?via=footballdata"><img width=152 src="https://football-data.co.uk/banners/oddsrelay-image.png"></a><P>

<table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#999999">
<tr><td bgcolor="#AAAAAA"><div class="menus"><B><FONT COLOR="#FFFFFF">DATA RESOURCES</FONT></B></div></td></tr>
<tr><td class="menustd"><div class="menus"><A title="historical football results and betting odds data archive" HREF="https://football-data.co.uk/data.php"><B>My CSV/Excel Data</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/thestatsapi.php"><B>FootballStatsAPI <font color="red">HOT</font></B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="oddsrelay.php"><B>Odds API Feed <font color="red">NEW</font></B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="footiqo.php"><B>More historical data</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="contact.php"><B>Your product here?</B></A></div></td></tr>
</table><P>

<A target="_blank" HREF="https://strategies.bet2invest.com/en-gb?ref=joseph"><img width=152 src="https://football-data.co.uk/banners/AD_BACKTEST_TODAY.gif"></a><P>

<table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#999999">
<tr><td bgcolor="#AAAAAA"><div class="menus"><B><FONT COLOR="#FFFFFF">OTHER RESOURCES</FONT></B></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://betting.football-data.co.uk"><B>Betting Guide</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><B><A target="_blank" HREF="https://strategies.bet2invest.com/en-gb?ref=joseph">Strategy Backtesting</A></B></div></td></tr>
<tr><td class="menustd"><div class="menus"><B><A HREF="https://football-data.co.uk/books.php">Books on Betting</A></B></div></td></tr>
<tr><td class="menustd"><div class="menus"><B><A HREF="https://football-data.co.uk/wisdom_of_crowd_bets.php">Wisdom of Crowds</A></B></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/ratings.pdf"><b>Football Ratings</b></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/profitable_betting_system.php"><b>Contrarian Betting</b></A></div></td></tr>
<!--  --><tr><td class="menustd"><div class="menus"><B><A HREF="https://football-data.co.uk/links.php">Other Sites</A></B></div></td></tr>
<tr><td class="menustd"><div class="menus"><B><A HREF="https://football-data.co.uk/link.php">Like Football-Data?</A></B></div></td></tr>
</table><P>

<!--
<div style="width: 152px; height: 152px; overflow: hidden;">
    <iframe 
        src="https://banner.bet365partners.com/grm_1371-996-64-7-149-1-4123.aspx" 
        width="200" 
        height="200" 
        frameborder="0" 
        scrolling="no" 
		rel="sponsored"
		click="${CLICKURL}"
        style="transform: scale(0.76); transform-origin: 0 0; width: 200px; height: 200px;">
    </iframe>
</div><P> 
 -->


<!-- 
<A HREF="https://football-data.co.uk/pinnacle_odds_dropper.php"><img src="https://football-data.co.uk/banners/1a.jpg" width=152></a><P>
 -->

<A target="_blank" HREF="https://www.pinnacleoddsdropper.com/?via=joseph&ref=Buchdahl"><img width=152 src="https://football-data.co.uk/banners/125x125-Dropping Odds.png"></a><P>


<!-- 
<A target="_blank" HREF="https://promo.betuk.com/gb/generic-football?btag=100668488_08e6149f7e5e4b3e81b5617a0f5bcc9c&pid=3775099&bid=20566"><img src="https://football-data.co.uk/banners/betuk.png" width=152></a><P>
-->

<table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#999999">
<tr><td bgcolor="#AAAAAA"><div class="menus"><B><FONT COLOR="#FFFFFF">BETTING ARTICLES</FONT></B></div></td></tr>
<tr><td class="menustd"><div class="menus"><B><A HREF="https://football-data.co.uk/blog/index.php">My Articles</A></B></div></td></tr>
<tr><td class="menustd"><div class="menus"><B><A HREF="https://www.pinnacle.com/betting-resources/en/author/joseph-buchdahl" target="_blank">Pinnacle Sportsbook</A></B></div></td></tr>
</table><P>

<!-- 
<a href="https://m.bluefoxaffiliates.com/redirect.aspx?mid=67&sid=789&cid=&pid=&affid=330" target="_blank" > <img width=100% alt="" src="https://m.bluefoxaffiliates.com/renderimage.aspx?mid=67&sid=789&cid=&pid=&affid=330" border="0" style="display:none;" > </img><img width=100% alt="" src="https://affiliates.bluefoxaffiliates.com/Banners/20240909153550942.gif" border="0"></img></a><P>-->


<table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#999999">
<tr><td bgcolor="#AAAAAA"><div class="menus"><B><FONT COLOR="#FFFFFF">BET CALCULATORS</FONT></B></div></td></tr>
<tr><td class="menustd"><div class="menus"><B><A HREF="https://football-data.co.uk/true_odds_calculator.xlsm" TARGET="_blank">Fair Odds</A></B></div></td></tr>
<tr><td class="menustd"><div class="menus"><B><A HREF="https://football-data.co.uk/blog/P-value_calculator.xlsx" TARGET="_blank">P-value</A></B></div></td></tr>
<tr><td class="menustd"><div class="menus"><B><A HREF="https://football-data.co.uk/yield_distribution_calculator.xlsx" TARGET="_blank">Yields</A></B></div></td></tr>
<tr><td class="menustd"><div class="menus"><B><A HREF="https://football-data.co.uk/percentage_staking_bank_growth_distribution_calculator.xlsx" TARGET="_blank">Bank growth</A></B></div></td></tr>
<tr><td class="menustd"><div class="menus"><B><A HREF="https://football-data.co.uk/EV_odds_function_calculator.xlsx" TARGET="_blank">EV-odds</A></B></div></td></tr>
<tr><td class="menustd"><div class="menus"><B><A HREF="https://football-data.co.uk/Kelly_animation.gif" TARGET="_blank">Staking Animation</A></B></div></td></tr>
</table><BR>

<table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#999999">
<tr><td bgcolor="#AAAAAA"><div class="menus"><B><FONT COLOR="#FFFFFF">ODDS & RESULTS:<BR>MAIN LEAGUES</FONT></B></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/matches.php"><b>Latest Matches</b></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/englandm.php"><b>England</b></A> <A HREF="https://football-data.co.uk/englandm.php"><IMG border=0 align="right" SRC="http://livescore.football-data.co.uk/flags/england.gif"</A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/scotlandm.php"><b>Scotland</b></A> <A HREF="https://football-data.co.uk/scotlandm.php"><IMG border=0 align="right" SRC="http://livescore.football-data.co.uk/flags/scotland.gif"</A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/germanym.php"><b>Germany</b></A> <A HREF="https://football-data.co.uk/germanym.php"><IMG border=0 align="right" SRC="http://livescore.football-data.co.uk/flags/germany.gif"</A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/italym.php"><b>Italy</b></A> <A HREF="https://football-data.co.uk/italym.php"><IMG border=0 align="right" SRC="http://livescore.football-data.co.uk/flags/italy.gif"</A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/spainm.php"><b>Spain</b></A> <A HREF="https://football-data.co.uk/spainm.php"><IMG border=0 align="right" SRC="http://livescore.football-data.co.uk/flags/spain.gif"</A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/francem.php"><b>France</b></A> <A HREF="https://football-data.co.uk/francem.php"><IMG border=0 align="right" SRC="http://livescore.football-data.co.uk/flags/france.gif"</A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/netherlandsm.php"><b>Netherlands</b></A> <A HREF="https://football-data.co.uk/netherlandsm.php"><IMG border=0 align="right" SRC="http://livescore.football-data.co.uk/flags/holland.gif"</A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/belgiumm.php"><b>Belgium</b></A> <A HREF="https://football-data.co.uk/belgiumm.php"><IMG border=0 align="right" SRC="http://livescore.football-data.co.uk/flags/belgium.gif"</A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/portugalm.php"><b>Portugal</b></A> <A HREF="https://football-data.co.uk/portugalm.php"><IMG border=0 align="right" SRC="http://livescore.football-data.co.uk/flags/portugal.gif"</A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/turkeym.php"><b>Turkey</b></A> <A HREF="https://football-data.co.uk/turkeym.php"><IMG border=0 align="right" SRC="http://livescore.football-data.co.uk/flags/turkey.gif"</A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/greecem.php"><b>Greece</b></A> <A HREF="https://football-data.co.uk/greecem.php"><IMG border=0 align="right" SRC="http://livescore.football-data.co.uk/flags/greece.gif"</A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/downloadm.php"><B>All Divisions</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><table cellpadding=0 border=0><td><b>Updates&nbsp;</b></td><td><a href="https://twitter.com/12Xpert" class="twitter-follow-button" data-show-count="false" data-show-screen-name="false">Follow @12Xpert</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script><t/td></table></div></td></tr>
</table><BR>

<table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#999999">
<tr><td bgcolor="#AAAAAA"><div class="menus"><B><FONT COLOR="#FFFFFF">ODDS & RESULTS:<BR>EXTRA LEAGUES</FONT></B></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/matches_new_leagues.php"><b>Latest Matches</b></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/argentina.php"><b>Argentina</b></A> <A HREF="https://football-data.co.uk/argentia.php"><IMG border=0 align="right" SRC="http://livescore.football-data.co.uk/flags/argentia.gif"</A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/austria.php"><b>Austria</b></A> <A HREF="https://football-data.co.uk/austria.php"><IMG border=0 align="right" SRC="http://livescore.football-data.co.uk/flags/austria.gif"</A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/brazil.php"><b>Brazil</b></A> <A HREF="https://football-data.co.uk/brazil.php"><IMG border=0 align="right" SRC="http://livescore.football-data.co.uk/flags/brazil.gif"</A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/china.php"><b>China</b></A> <A HREF="https://football-data.co.uk/china.php"><IMG border=0 align="right" SRC="http://livescore.football-data.co.uk/flags/china.gif"</A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/denmark.php"><b>Denmark</b></A> <A HREF="https://football-data.co.uk/denmark.php"><IMG border=0 align="right" SRC="http://livescore.football-data.co.uk/flags/denmark.gif"</A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/finland.php"><b>Finland</b></A> <A HREF="https://football-data.co.uk/finland.php"><IMG border=0 align="right" SRC="http://livescore.football-data.co.uk/flags/finland.gif"</A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/ireland.php"><b>Ireland</b></A> <A HREF="https://football-data.co.uk/ireland.php"><IMG border=0 align="right" SRC="http://livescore.football-data.co.uk/flags/ireland.gif"</A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/japan.php"><b>Japan</b></A> <A HREF="https://football-data.co.uk/japan.php"><IMG border=0 align="right" SRC="http://livescore.football-data.co.uk/flags/japan.gif"</A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/mexico.php"><b>Mexico</b></A> <A HREF="https://football-data.co.uk/mexico.php"><IMG border=0 align="right" SRC="http://livescore.football-data.co.uk/flags/mexico.gif"</A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/norway.php"><b>Norway</b></A> <A HREF="https://football-data.co.uk/norway.php"><IMG border=0 align="right" SRC="http://livescore.football-data.co.uk/flags/norway.gif"</A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/poland.php"><b>Poland</b></A> <A HREF="https://football-data.co.uk/poland.php"><IMG border=0 align="right" SRC="http://livescore.football-data.co.uk/flags/poland.gif"</A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/romania.php"><b>Romania</b></A> <A HREF="https://football-data.co.uk/romania.php"><IMG border=0 align="right" SRC="http://livescore.football-data.co.uk/flags/romania.gif"</A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/russia.php"><b>Russia</b></A> <A HREF="https://football-data.co.uk/russia.php"><IMG border=0 align="right" SRC="http://livescore.football-data.co.uk/flags/russia.gif"</A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/sweden.php"><b>Sweden</b></A> <A HREF="https://football-data.co.uk/sweden.php"><IMG border=0 align="right" SRC="http://livescore.football-data.co.uk/flags/sweden.gif"</A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/switzerland.php"><b>Switzerland</b></A> <A HREF="https://football-data.co.uk/switzerland.php"><IMG border=0 align="right" SRC="http://livescore.football-data.co.uk/flags/swiss.gif"</A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/usa.php"><b>USA</b></A> <A HREF="https://football-data.co.uk/usa.php"><IMG border=0 align="right" SRC="http://livescore.football-data.co.uk/flags/usa.gif"</A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="https://football-data.co.uk/all_new_data.php"><B>All Divisions</B></A></div></td></tr>
</table><BR>

<A target=_"blank" HREF="https://www.pinnacleoddsdropper.com/?via=joseph&ref=Buchdahl"><img src="https://football-data.co.uk/banners/POD_BANNER_AD_US.png" width=152></a><P>

<table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#999999">
<tr><td bgcolor="#AAAAAA"><div class="menus"><B><FONT COLOR="#FFFFFF">TOP RESOURCES</FONT></B></div></td></tr>
<tr><td class="menustd"><div class="menus"><A target=_"blank" HREF="https://valuebetfactory.com/"><b>Value Betting Tool</b></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A target=_"blank" HREF="https://bookiesbonuses.com/"><b>Bookie Bonuses</b></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="../resources/goonersguide.php"><B>Gooners Guide</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A target=_"blank" HREF="https://www.top100bookmakers.com/"><B>Top 100 Bookmakers</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A target=_"blank" HREF="https://www.casinoadvisor.com"><B>Casino Advisor</B></A></div></td></tr>
</table><BR>

<table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#999999">
<tr><td bgcolor="#AAAAAA"><div class="menus"><B><FONT COLOR="#FFFFFF">LIVESCORES</FONT></B></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="http://livescore.football-data.co.uk"><B>Live Scores</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A target=_"blank" HREF="https://www.flashscore.co.uk"><B>Football Scores</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A target=_"blank" HREF="https://www.flashscore.com"><B>Live Soccer</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="../resources/statisticsports.php"><B>Statisticsports</B></A></div></td></tr>
</table><BR>

<table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#999999">
<tr><td bgcolor="#AAAAAA"><div class="menus"><B><FONT COLOR="#FFFFFF">STATS</FONT></B></div></td></tr>
<tr><td class="menustd"><div class="menus"><A target=_"blank" HREF="https://soccerbets.com/"><B>Soccer Bets</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A target=_"blank" HREF="https://makeyourstats.com/"><B>MakeYourStats</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A target=_"blank" HREF="https://footystats.org"><B>FootyStats</B></A></div></td></tr>
</table><BR>

<table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#999999">
<tr><td bgcolor="#AAAAAA"><div class="menus"><B><FONT COLOR="#FFFFFF">ODDS</FONT></B></div></td></tr>
<tr><td class="menustd"><div class="menus"><A target=_"blank" HREF="http://www.oddsportal.com/"><B>Betting Odds</B></A></div></td></tr>
</table><BR>

<table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#999999">
<tr><td bgcolor="#AAAAAA"><div class="menus"><B><FONT COLOR="#FFFFFF">BETTING</FONT></B></div></td></tr>
<tr><td class="menustd"><div class="menus"><A target=_"blank" HREF="http://www.betexplorer.com/"><B>BetExplorer</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A target=_"blank" HREF="https://caanberry.com/"><B>Betfair Trading</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="../resources/godsofodds.php"><B>GodsOfOdds</B></A></div></td></tr>
<tr><td class="menustd"><div class="menus"><A target=_"blank" HREF="https://www.soccerwidow.com/" title="About Football, Gambling, Statistics, Betting Maths and Strategies"><B>Soccerwidow</B></A></div></td></tr>
</table><BR>

<table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#999999">
<tr><td bgcolor="#AAAAAA"><div class="menus"><B><FONT COLOR="#FFFFFF">CASINO</FONT></B></div></td></tr>
<tr><td class="menustd"><div class="menus"><A target=_"blank" HREF="https://campaigns.williamhill.com/C.ashx?btag=a_87b_1125c_&affid=1213609&siteid=87&adid=1125&c="><B>William Hill Vegas</B></A></div></td></tr>
</table><BR>


<table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#999999">
<tr><td bgcolor="#AAAAAA"><div class="menus"><B><FONT COLOR="#FFFFFF">FOOTBALL</FONT></B></div></td></tr>
<tr><td class="menustd"><div class="menus"><A HREF="http://injuriesandsuspensions.com" target=_"blank"><b>Injuries & Suspensions</b></A></div></td></tr>
</table><BR>

<table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#999999">
<tr><td bgcolor="#AAAAAA"><div class="menus"><B><FONT COLOR="#FFFFFF">FORUMS</FONT></B></div></td></tr>
<tr><td class="menustd"><div class="menus"><A target=_"blank" HREF="http://www.punterslounge.com"><b>Punters Lounge</b></A></div></td></tr>
</table><BR>

<table width="100%" border="0" cellspacing="1" cellpadding="1" bgcolor="#999999">
<tr><td bgcolor="#AAAAAA"><div class="menus"><B><FONT COLOR="#FFFFFF">US BETTORS</FONT></B></div></td></tr>
<tr><td class="menustd"><div class="menus"><A target=_"blank" HREF="https://www.oddstrader.com/sportsbooks/offshore-versus-regulated/"><b>Best Offshore Sportsbooks</b></A></div></td></tr>
</table><BR>

</TD>

</TR></TABLE>
</BODY>
</HTML>
